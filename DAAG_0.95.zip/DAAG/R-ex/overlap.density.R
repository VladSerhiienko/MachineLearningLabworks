### Name: overlap.density
### Title: Overlapping Density Plots - obsolete
### Aliases: overlap.density
### Keywords: models

### ** Examples

attach(two65)
overlap.density(ambient,heated)
t.test(ambient,heated)



