"elastic1" <-
structure(list(stretch = c(46, 54, 48, 50, 44, 42, 52), distance = c(183, 
217, 189, 208, 178, 150, 249)), .Names = c("stretch", "distance"
), row.names = c("1", "2", "3", "4", "5", "6", "7"), class = "data.frame")
