### Name: onetPermutation
### Title: One Sample Permutation t-test
### Aliases: onetPermutation
### Keywords: models

### ** Examples

onetPermutation()



