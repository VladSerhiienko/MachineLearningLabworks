`pause` <-
function () 
{
    cat("Pause. Press <Enter> to continue...")
    readline()
    invisible()
}
