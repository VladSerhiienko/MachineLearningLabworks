### Name: twot.permutation
### Title: Two Sample Permutation Test - Obsolete
### Aliases: twot.permutation
### Keywords: models

### ** Examples

twot.permutation()



