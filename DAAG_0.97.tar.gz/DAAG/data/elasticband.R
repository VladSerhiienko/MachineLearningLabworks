"elasticband" <-
structure(list(stretch = c(46, 54, 48, 50, 44, 42, 52), distance = c(148, 
182, 173, 166, 109, 141, 166)), .Names = c("stretch", "distance"
), row.names = c("1", "2", "3", "4", "5", "6", "7"), class = "data.frame")
