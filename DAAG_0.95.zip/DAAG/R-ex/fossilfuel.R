### Name: fossilfuel
### Title: Fossil Fuel Data
### Aliases: fossilfuel
### Keywords: datasets

### ** Examples

plot(fossilfuel)



