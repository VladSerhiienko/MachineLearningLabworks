### Name: poissonsim
### Title: Simple Poisson Regression Data Simulator
### Aliases: poissonsim
### Keywords: models

### ** Examples

poissonsim()



