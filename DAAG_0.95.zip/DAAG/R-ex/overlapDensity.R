### Name: overlapDensity
### Title: Overlapping Density Plots
### Aliases: overlapDensity
### Keywords: models

### ** Examples

attach(two65)
overlapDensity(ambient,heated)
t.test(ambient,heated)



