"modelcars" <-
structure(list(distance.traveled = c(31.375, 30.375, 33.625, 
26.625, 25.75, 27.125, 18.75, 22.5, 21.625, 13.875, 11.75, 14.875
), starting.point = c(12, 12, 12, 9, 9, 9, 6, 6, 6, 3, 3, 3)), .Names = c("distance.traveled", 
"starting.point"), row.names = c("241", "242", "243", "244", 
"245", "246", "247", "248", "249", "250", "251", "252"), class = "data.frame")
