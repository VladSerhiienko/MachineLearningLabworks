"primates" <-
structure(list(Bodywt = c(10, 207, 62, 6.8, 52.2), Brainwt = c(115, 
406, 1320, 179, 440)), .Names = c("Bodywt", "Brainwt"), class = "data.frame", row.names = c("Potar monkey", 
"Gorilla", "Human", "Rhesus monkey", "Chimp"))
