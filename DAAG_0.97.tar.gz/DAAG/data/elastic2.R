"elastic2" <-
structure(list(stretch = c(30, 50, 40, 45, 60, 55, 35, 55, 65
), distance = c(71, 196, 127, 187, 249, 217, 114, 228, 291)), .Names = c("stretch", 
"distance"), class = "data.frame", row.names = c("1", "2", "3", 
"4", "5", "6", "7", "8", "9"))
