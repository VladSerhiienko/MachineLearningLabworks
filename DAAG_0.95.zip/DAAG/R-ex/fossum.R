### Name: fossum
### Title: Female Possum Measurements
### Aliases: fossum
### Keywords: datasets

### ** Examples

boxplot(fossum$totlngth)



