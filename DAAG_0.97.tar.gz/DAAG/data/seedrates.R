"seedrates" <-
structure(list(rate = c(50, 75, 100, 125, 150), grain = c(21.2, 
19.9, 19.2, 18.4, 17.9)), .Names = c("rate", "grain"), class = "data.frame", row.names = c("1", 
"2", "3", "4", "5"))
