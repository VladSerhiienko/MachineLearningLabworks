### Name: rainforest
### Title: Rainforest Data
### Aliases: rainforest
### Keywords: datasets

### ** Examples

table(rainforest$species)



