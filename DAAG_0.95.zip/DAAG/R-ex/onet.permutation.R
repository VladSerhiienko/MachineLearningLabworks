### Name: onet.permutation
### Title: One Sample Permutation t-test
### Aliases: onet.permutation
### Keywords: models

### ** Examples

onet.permutation()



