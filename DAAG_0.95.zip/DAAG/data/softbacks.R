"softbacks" <-
structure(list(volume = c(412, 953, 929, 1492, 419, 1010, 595, 
1034), weight = c(250, 700, 650, 975, 350, 950, 425, 725)), .Names = c("volume", 
"weight"), class = "data.frame", row.names = c("1", "2", "3", 
"4", "5", "6", "7", "8"))
