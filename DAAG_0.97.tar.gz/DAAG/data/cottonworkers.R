"cottonworkers" <-
structure(list(census1886 = c(5902, 375, 909, 2883, 1983, 208, 
669, 2966, 597, 6951, 865, 1586, 0, 8577), survey1889 = c(2, 
1, 12, 37, 17, 17, 4, 44, 6, 156, 5, 14, 4, 21), avwage = c(233.59, 
328.98, 388.47, 466.54, 399.9, 269.73, 440.82, 311.64, 469.62, 
408.97, 357.2, 308.73, 456.23, 273.97)), .Names = c("census1886", 
"survey1889", "avwage"), row.names = c("Big piecer", "Drawer in", 
"Engineman", "Foreman", "Grinders", "Labourer", "Mechanic", "Others", 
"Sizer", "Spinner", "Twister in", "Warehouseman", "Warp dresser", 
"Weaver"), class = "data.frame")
