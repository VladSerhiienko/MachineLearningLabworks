"two65" <-
structure(list(heated = c(254, 252, 239, 240, 250, 256, 267, 
249, 259, 269), ambient = c(233, 252, 237, 246, 255, 244, 248, 
242, 217, 257, 254)), .Names = c("heated", "ambient"))
