### Name: hills2000
### Title: Scottish Hill Races Data - 2000
### Aliases: hills2000
### Keywords: datasets

### ** Examples

    pairs(hills2000)



