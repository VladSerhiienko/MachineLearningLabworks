### Name: simulateLinear
### Title: Simulation of Linear Models for ANOVA vs. Regression Comparison
### Aliases: simulateLinear
### Keywords: models

### ** Examples

simulateLinear()



