### Name: whoops
### Title: Deaths from whooping cough, in London
### Aliases: whoops
### Keywords: datasets

### ** Examples

data(whoops)
str(whoops)
plot(whoops) 



