### Name: show.colors
### Title: Show R's Colors
### Aliases: show.colors
### Keywords: models

### ** Examples

require(MASS)
show.colors()



