### Name: races2000
### Title: Scottish Hill Races Data - 2000
### Aliases: races2000
### Keywords: datasets

### ** Examples

    pairs(races2000[,-11])



