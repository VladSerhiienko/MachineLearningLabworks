"sugar" <-
structure(list(weight = c(82, 97.8, 69.9, 58.3, 67.9, 59.3, 68.1, 
70.8, 63.6, 50.7, 47.1, 48.9), trt = structure(c(1, 1, 1, 2, 
2, 2, 3, 3, 3, 4, 4, 4), .Label = c("Control", "A", "B", "C"), class = 
"factor")), .Names = c("weight", 
"trt"), row.names = c("1", "2", "3", "4", "5", "6", "7", "8", 
"9", "10", "11", "12"), class = "data.frame")
