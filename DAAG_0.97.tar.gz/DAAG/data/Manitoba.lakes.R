"Manitoba.lakes" <-
structure(list(elevation = c(217, 254, 248, 254, 253, 227, 178, 
207, 217), area = c(24387, 5374, 4624, 2247, 1353, 1223, 1151, 
755, 657)), .Names = c("elevation", "area"), class = "data.frame", row.names = c("Winnipeg", 
"Winnipegosis", "Manitoba", "SouthernIndian", "Cedar", "Island", 
"Gods", "Cross", "Playgreen"))
