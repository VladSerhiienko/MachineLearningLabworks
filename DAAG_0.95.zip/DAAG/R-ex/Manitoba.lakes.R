### Name: Manitoba.lakes
### Title: The Nine Largest Lakes in Manitoba
### Aliases: Manitoba.lakes
### Keywords: datasets

### ** Examples

plot(Manitoba.lakes)
plot(Manitoba.lakes[-1,])



