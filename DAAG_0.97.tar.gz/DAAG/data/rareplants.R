"rareplants" <-
structure(c(37, 23, 10, 15, 190, 59, 141, 58, 94, 23, 28, 16), .Dim = c(4, 
3), .Dimnames = list(c("CC", "CR", "RC", "RR"), c("D", "W", "WD"
)))
