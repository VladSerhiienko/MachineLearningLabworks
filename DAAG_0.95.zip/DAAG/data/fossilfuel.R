"fossilfuel" <-
structure(list(year = c(1800, 1850, 1900, 1950, 2000), carbon = c(8, 
54, 534, 1630, 6611)), .Names = c("year", "carbon"), row.names = c("1", 
"2", "3", "4", "5"), class = "data.frame")
