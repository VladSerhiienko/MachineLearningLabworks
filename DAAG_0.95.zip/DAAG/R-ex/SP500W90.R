### Name: SP500W90
### Title: Closing Numbers for S and P 500 Index - First 100 Days of 1990
### Aliases: SP500W90
### Keywords: datasets

### ** Examples

ts.plot(SP500W90)



