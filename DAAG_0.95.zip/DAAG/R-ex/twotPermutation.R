### Name: twotPermutation
### Title: Two Sample Permutation Test
### Aliases: twotPermutation
### Keywords: models

### ** Examples

twotPermutation()



