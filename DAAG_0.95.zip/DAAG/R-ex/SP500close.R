### Name: SP500close
### Title: Closing Numbers for S and P 500 Index
### Aliases: SP500close
### Keywords: datasets

### ** Examples

ts.plot(SP500close)



