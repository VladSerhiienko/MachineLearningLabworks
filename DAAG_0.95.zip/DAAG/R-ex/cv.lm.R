### Name: cv.lm
### Title: Cross-Validation for Linear Regression
### Aliases: cv.lm
### Keywords: models

### ** Examples

cv.lm()



