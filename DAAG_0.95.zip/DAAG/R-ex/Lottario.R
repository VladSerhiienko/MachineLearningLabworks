### Name: Lottario
### Title: Ontario Lottery Data
### Aliases: Lottario
### Keywords: datasets

### ** Examples
 
order(Lottario$Frequency)[33:39]  # the 7 most frequently chosen numbers



