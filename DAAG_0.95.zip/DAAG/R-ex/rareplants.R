### Name: rareplants
### Title: Rare and Endangered Plant Species
### Aliases: rareplants
### Keywords: datasets datasets

### ** Examples

chisq.test(rareplants)



