### Name: logisticsim
### Title: Simple Logistic Regression Data Simulator
### Aliases: logisticsim
### Keywords: models

### ** Examples

logisticsim()



