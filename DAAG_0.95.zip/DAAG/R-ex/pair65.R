### Name: pair65
### Title: Heated Elastic Bands
### Aliases: pair65
### Keywords: datasets

### ** Examples

mean(pair65$heated - pair65$ambient)
sd(pair65$heated - pair65$ambient)



