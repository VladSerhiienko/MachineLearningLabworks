### Name: two65
### Title: Unpaired Heated Elastic Bands
### Aliases: two65
### Keywords: datasets

### ** Examples

twot.permutation(two65$ambient,two65$heated) # two sample permutation test



