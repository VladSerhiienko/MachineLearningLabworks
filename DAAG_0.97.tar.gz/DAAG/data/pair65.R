"pair65" <-
structure(list(heated = c(244, 255, 253, 254, 251, 269, 248, 
252, 292), ambient = c(225, 247, 249, 253, 245, 259, 242, 255, 
286)), .Names = c("heated", "ambient"), row.names = c("1", "2", 
"3", "4", "5", "6", "7", "8", "9"), class = "data.frame")
