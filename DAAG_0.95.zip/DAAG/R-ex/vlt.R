### Name: vlt
### Title: Video Lottery Terminal Data
### Aliases: vlt
### Keywords: datasets

### ** Examples

     vlt.stk <- stack(vlt[,1:3])
     table(vlt.stk)



