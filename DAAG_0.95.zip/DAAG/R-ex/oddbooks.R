### Name: oddbooks
### Title: Measurements on 12 books
### Aliases: oddbooks
### Keywords: datasets

### ** Examples

data(oddbooks)
str(oddbooks)
plot(oddbooks) 



